boolean UserName ( char *query_string )

{
	NWCONN_HANDLE  conn;
	NWCONN_NUM     connNumber;
	char           user_name[48];
	NWOBJ_TYPE     objectType=OT_USER;
	NWOBJ_ID       objectID;
	BYTE           loginTime[7];
	char 		   *server_query, *user_query;

	server_query = user_query = query_string;

	while ( *query_string != '\0'){
		if (*query_string == '/'){
			*query_string = '\0';
			user_query = query_string;
			user_query++;
		}
		else
			query_string++;
	}

	if (NWCallsInit(NULL,NULL))
		return(NO);

	if (user_query==server_query){
		if (NWGetDefaultConnectionID( &conn))
			return(NO);
	}
	else{
		strupr(server_query);
		if (NWGetConnectionHandle(server_query,0,&conn,NULL))
			return(NO);
	}

	if (NWGetConnectionNumber( conn , &connNumber))
		return(NO);

	if (NWGetConnectionInformation( conn, connNumber, user_name, &objectType, &objectID, loginTime ))
		return(NO);

	if (stricmp(user_name,user_query))
		return(NO);

	return(YES);
};

//****************************************************************************
boolean IsMember (char *query_string)

{
	NWCONN_HANDLE  conn;
	NWCONN_NUM     connNumber;
	char           user_name[48];
	NWOBJ_TYPE     objectType=OT_USER;
	NWOBJ_ID       objectID;
	BYTE           loginTime[7];
	char 		   *server_query, *group_query;
	char 	  		propertyName[]="GROUPS_I'M_IN";
	NWOBJ_TYPE     memberType;

	server_query = group_query = query_string;

	while ( *query_string != '\0'){
		if (*query_string == '/'){
			*query_string = '\0';
			group_query = query_string;
			group_query++;
		}
		else
			query_string++;
	}

	if (NWCallsInit(NULL,NULL))
		return(NO);

	if (group_query==server_query){
		if (NWGetDefaultConnectionID( &conn))
			return(NO);
	}
	else{
		strupr(server_query);
		if (NWGetConnectionHandle(server_query,0,&conn,NULL))
			return(NO);
	}

	if (NWGetDefaultConnectionID( &conn))
		return(NO);

	if (NWGetConnectionNumber( conn, &connNumber))
		return(NO);

	if (NWGetConnectionInformation( conn, connNumber, user_name, &objectType, &objectID, loginTime ))
		return(NO);

	memberType=OT_USER_GROUP;
	objectType=OT_USER;

	if ( !NWIsObjectInSet (conn, user_name, objectType, propertyName, group_query, memberType) )
		return (YES);
	return (NO);
};
